
const HeroSection = () =>{



    return <main className ="hero container">


       <div className="hero-content">

        <h1>
        DRESS LIKE YOU'R ALREADY FAMOUS
        </h1>

        <p>
        DRESS LIKE YOU'R ALREADY FAMOUS AND WE'RE HERE TO HELP YOU WITH OUR CLOTHES
        TO SLAY WITH YOUR SASSY CLOTHES AND VIBE.
        </p>


       <div className="hero-btn">
       <button>shop Now</button>
       <button className="secondary-btn">Category</button>
       </div>



      <div className="Shopping">

      <p> Also Available On</p>

     <div className="brand-icons">  
     <img src ="/images/flipkart.png" alt ="flipkart-logo" />
     <img src="/images/amazon.png"  alt = "amazon-logo" />
     </div>

      </div>


       </div>



       <div className="hero-image">
        <img src="/images/img.png" alt="img-logo" />
       </div>

       <div className="name">KAMAL FASHION GALLERY</div>

    </main>
};

export default HeroSection;
